/***************************
*    Questao 5             *
*    Matheus Araujo Langer *
*    722                   *
*    21/10/2019            *
****************************/

#include <stdio.h>
#include <stdlib.h>

float celsiusToFahrenheit(float tc)
{
    return (tc*1.8) + 32;
}

int main()
{
    int i;
    float  tempCelsius[3];
    printf("Digite tres temperaturas em Celsius: ");
    for (i = 0; i < 3; i++)
    {
        scanf("%f", &tempCelsius[i]);
    }
    printf("Resultado da Conversao:\n");
    printf("Celsius\t\tFahrenheit\n");
    for (i = 0; i < 3; i++)
        printf("%.2f\t\t%.2f\n", tempCelsius[i],celsiusToFahrenheit(tempCelsius[i]));
    printf("%d valores foram convertidos", i);
    return 0;
}
