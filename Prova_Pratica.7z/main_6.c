/***************************
*    Questao 6             *
*    Matheus Araujo Langer *
*    722                   *
*    21/10/2019            *
****************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#define TAM 5

void geraRampa(uint8_t vetor[], int tam, int8_t inclinacao);
void imprimeSinal(uint8_t vetor[], int tam);

int main()
{
    uint8_t sinal[TAM];
    geraRampa(sinal, 5, 6);
    imprimeSinal(sinal, 5);
    return 0;
}

void imprimeSinal(uint8_t vetor[], int tam)
{
    int k;
    for (k = 0; k < tam; k++)
    {
        printf("%d\n", vetor[k]);
    }
}

void geraRampa(uint8_t vetor[], int tam, int8_t inclinacao)
{
    int k;
    for (k = 0; k < tam; k++)
    {
        vetor[0] = 255;
        vetor[k] = vetor[k-1] - inclinacao;
    }
}
