#ifndef PONTOCIRC_H_INCLUDED
#define PONTOCIRC_H_INCLUDED

//Definicao das Estruturas
struct Ponto2D{
        float x;
        float y;
    };
struct CorRGB{
        unsigned int r;
        unsigned int g;
        unsigned int b;
};

struct Circulo{
        struct Ponto2D centro;
        float raio;
        struct CorRGB cor;
};


//Funcoes
void leInstancias(struct Ponto2D *p, struct Circulo *c);
void mostraInstancias(const struct Ponto2D *p, const struct Circulo *c);
int ehInterno(const struct Ponto2D *p, const struct Circulo *c);
int leArquivoInstancias(char nomearquivo[], struct Ponto2D *p, struct Circulo *c);
void desenhaCirculo(const struct Circulo *c);

#endif // PONTOCIRC_H_INCLUDED
