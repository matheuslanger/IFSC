#include <stdio.h>
#include <stdlib.h>
#include "pontocirc.h"

int main(void) {
    struct Ponto2D ponto1; //cria instancia Etapa 4
    struct Circulo circ1;

    leInstancias(&ponto1, &circ1);

    mostraInstancias(&ponto1, &circ1);

    if (ehInterno(&ponto1, &circ1)) {
        printf("Ponto dentro do circulo\n");
    }

    struct Ponto2D ponto2; //cria instancia Etapa 4
    struct Circulo circ2;
    leArquivoInstancias("geometricos.txt", &ponto2, &circ2);

    printf("Lidos a partir do arquivo\n");
    mostraInstancias(&ponto2, &circ2);

    //return sqrt(pow((p->y-c->y),2)+(pow((p->x-c->x),2)));
    return 0;
}
