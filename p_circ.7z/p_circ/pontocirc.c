#include <stdio.h>
#include <math.h>
#include <string.h>
#include "pontocirc.h"

//Implementacao das funcoes
void leInstancias(struct Ponto2D *p, struct Circulo *c)
{
    printf("Digite duas coordenadas:\n");
    scanf("%f %f", &p->x, &p->y);
    printf("Digite as coordenadas X e Y do centro de um circulo:\n");
    scanf("%f %f", &c->centro.x, &c->centro.y);
    printf("Digite os valores RGB do circulo:\n");
    scanf("%d %d %d", &c->cor.r, &c->cor.g, &c->cor.b);
    printf("Digite o valor do raio:\n");
    scanf("%f", &c->raio);
}

void mostraInstancias(const struct Ponto2D *p, const struct Circulo *c)
{
    printf("%.2f %.2f\n", p->x, p->y);
    printf("%.2f %.2f\n", c->centro.x, c->centro.y);
    printf("%d %d %d\n", c->cor.r, c->cor.g, c->cor.b);
    printf("%.2f\n", c->raio);

}

int ehInterno(const struct Ponto2D *p, const struct Circulo *c)
{
    float k = sqrt(pow((p->y-c->centro.y),2)+(pow((p->x-c->centro.x),2)));
    if (k < c->raio){
        return 1;
    }
    else{
     printf("Ponto fora do circulo\n");
     return 0;
    }
}
int leArquivoInstancias(char nomearquivo[], struct Ponto2D *p, struct Circulo *c)
{
  char s1[20], s3[20];
  int n;
  FILE *fp;
  fp = fopen(nomearquivo,"r");
  if (fp == NULL)  {
    printf("Erro ao abrir arquivo %s.\n", nomearquivo);
    return -1;
  }
  fgets(s1, sizeof(s1), fp);
  n = fscanf("%f %f", &p->x, &p->y);
  fgets(s3, sizeof(s3), fp);
  n = fscanf("%f %f %f %d %d %d", &c->centro.x, &c->centro.y, &c->raio, &c->cor.r, &c->cor.g, &c->cor.b);
    return 1;
}
void desenhaCirculo(const struct Circulo *c)
{

}

