#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 50

const char NOME_ARQ[] = "TESTE.txt";

struct Carro{
    int ano[N];
    float preco[N];
    char marca[N][30];
    char modelo[N][30];
};

int main ()  {
  struct Carro carro1[N];
  int tam_lin = 0, n, i, k = 0, j = 0;
  FILE *fp;
  fp = fopen(NOME_ARQ,"r");
  if (fp == NULL)  {
    printf("Erro ao abrir arquivo %s.\n", NOME_ARQ);
    exit(1);
  }
  while(1)  {
      if (n==EOF)
        break;
      n = fscanf(fp, "%s%s%d%f", carro1[i].marca, carro1[i].modelo, &carro1[i].ano, &carro1[i].preco);
      tam_lin++;
  }
  fclose(fp);
    for(i = 0; i < N; i++){
        printf("Marca: %s\tModelo: %s\tAno: %d\tPreco: %.2f\n", carro1[i].marca, carro1[i].modelo, carro1[i].ano, carro1[i].preco);
    }

    for(i = 0; i< N; i++){
        if (carro1[i].ano < k){
            k = i;
        }
        if (carro1[i].preco > j){
            j = i;
        }

    }

    printf("O carro mais velho e %s %s e o carro mais caro e %.2f\n", carro1[k].marca, carro1[k].modelo, carro1[j].preco);

  return 0;
  }

