#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define L 29
const char NOME_ARQ[] = "dados_temperatura_thingspeak.csv";

float fahr2celsius(float tf){
    return ((tf-32)*5)/9;
}

int main()
{
  int i, n, hora[L], minuto[L], j = 0, k = 0;
  float temp[L];
  FILE *fp;
  fp = fopen(NOME_ARQ,"r");
  if (fp == NULL)  {
    printf("Erro ao abrir arquivo %s.\n", NOME_ARQ);
    exit(1);
  }
  while(1)  {
    for (i = 0; i < L; i++){
    n = fscanf(fp, "%d%d%f", &hora[i], &minuto[i], &temp[i]);
    if (n==EOF)
        break;
    }
  }
    fclose(fp);
    for (i = 0; i < L; i++){
        fprintf(fp, "%d:%d --> %f�F", hora[i], minuto[i], temp[i]);
    }





    return 0;
}
