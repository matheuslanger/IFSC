#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 3

const char NOME_ARQ[] = "TESTE.txt";
int main ()  {
  int n, i, k = 0, j = 0;
  int ano[N];
  float preco[N];
  char marca[N][30], modelo[N][30];
  FILE *fp;
  fp = fopen(NOME_ARQ,"r");
  if (fp == NULL)  {
    printf("Erro ao abrir arquivo %s.\n", NOME_ARQ);
    exit(1);
  }
  while(1)  {
    for(i = 0; i < N; i++){
      if (n==EOF)
        break;
      n = fscanf(fp, "%s%s%d%f", marca[i], modelo[i], &ano[i], &preco[i]);
  }
  fclose(fp);
    for(i = 0; i < N; i++){
        printf("Marca: %s\tModelo: %s\tAno: %d\tPreco: %.2f\n", marca[i], modelo[i], ano[i], preco[i]);
    }

    for(i = 0; i< N; i++){
        if (ano[i] < k){
            k = i;
        }
        if (preco[i] > j){
            j = i;
        }

    }

    printf("O carro mais velho e %s %s e o carro mais caro e %.2f\n", marca[k], modelo[k], preco[j]);

  return 0;
  }
}
